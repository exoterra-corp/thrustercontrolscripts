"""A module to allow CAN over UDP on IPv4/IPv6 multicast."""

from .bus import UdpMulticastBus
