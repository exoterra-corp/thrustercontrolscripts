"""
See: https://www.kernel.org/doc/Documentation/networking/can.txt
"""

from .socketcan import SocketcanBus, CyclicSendTask, MultiRateCyclicSendTask
