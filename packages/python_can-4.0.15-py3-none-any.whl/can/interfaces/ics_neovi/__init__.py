"""
"""

from can.interfaces.ics_neovi.neovi_bus import NeoViBus
