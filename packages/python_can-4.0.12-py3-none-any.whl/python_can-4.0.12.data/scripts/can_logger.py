#!python

"""
See :mod:`can.logger`.
"""

from can.logger import main


if __name__ == "__main__":
    main()
